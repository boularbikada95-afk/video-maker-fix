"""Quiz template — 60s, 6 questions, 10s each, paper background."""
from brain import make_plan


def build_quiz_plan(questions=None, duration=60):
    plan = make_plan("quiz", template="Quiz", duration=duration)
    if questions:
        for scene, q in zip(plan["scenes"], questions):
            scene["text"] = q
    return plan
