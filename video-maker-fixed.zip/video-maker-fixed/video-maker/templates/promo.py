"""Promo template — 17s, IDeCom Visuals style."""
from brain import make_plan


def build_promo_plan(brand="iD", main_text="MARKETING", duration=17):
    return make_plan("promo", template="Promo", brand=brand,
                     main_text=main_text, duration=duration)
