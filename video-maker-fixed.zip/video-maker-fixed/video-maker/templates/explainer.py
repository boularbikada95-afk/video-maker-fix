"""Explainer template — 60-90s, 8 scenes, one idea per scene."""
from brain import split_topic_to_scenes


def build_explainer_plan(topic_text, duration=80):
    scenes = split_topic_to_scenes(topic_text, scene_seconds=10)
    return {"duration": duration, "width": 1080, "height": 1920, "fps": 24,
            "template": "Explainer", "scenes": scenes, "voice_text": topic_text}
