"""Brain: command -> JSON plan, topic -> scenes, Darija correction.

FIX #5: custom Darija words are loaded from darija_custom.json (safe
JSON, invalid file never crashes). darija_dict.py is read-only base.
FIX #7: Gemini is called via gemini_rest.py (requests), never via the
deprecated google-generativeai package.
Captions ALWAYS keep the original Darija word; the MSA meaning is shown
beside it in the UI for understanding / image keywords only.
"""
import json
import os
import re

from config import DARIJA_CUSTOM_FILE
from darija_dict import BASE_DARIJA
from style_engine import detect_topic_category, get_style_for_topic

COLOR_WORDS = {"أصفر": "yellow", "أخضر": "green", "برتقالي": "orange",
               "أحمر": "red", "أزرق": "blue", "yellow": "yellow",
               "green": "green", "orange": "orange", "red": "red", "blue": "blue"}

AR_TO_EN_KEYWORDS = {
    "محرك طائرة": "jet engine", "محرك سيارة": "car engine",
    "طائرة": "airplane", "سيارة": "car", "بحر": "sea",
    "حب": "couple love", "فراق": "heartbreak",
}


def load_custom_darija():
    """FIX #5: safe JSON load — invalid JSON returns {} and never crashes."""
    try:
        with open(DARIJA_CUSTOM_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_custom_darija(words):
    """Save user words to JSON (not to darija_dict.py)."""
    if not isinstance(words, dict):
        raise ValueError("words must be a dict")
    with open(DARIJA_CUSTOM_FILE, "w", encoding="utf-8") as f:
        json.dump(words, f, ensure_ascii=False, indent=2)


def merge_darija_dicts():
    merged = dict(BASE_DARIJA)
    merged.update(load_custom_darija())
    return merged


def darija_to_msa(text):
    """Return (darija_original, msa_meaning). Captions use the original."""
    merged = merge_darija_dicts()
    meaning = str(text or "")
    for darija_word, msa in merged.items():
        meaning = meaning.replace(darija_word, msa)
    return text, meaning


def correct_darija_transcript(text, gemini_key=None):
    """Correct clear Whisper errors, keep Darija words as spoken."""
    original, meaning = darija_to_msa(text)
    if gemini_key:
        try:
            from gemini_rest import generate_text
            out = generate_text(
                gemini_key,
                "This is Algerian Darija transcript, it may have Whisper "
                "errors. Correct only clear errors, keep the Darija words "
                f"as spoken, do not convert to Fusha, return the corrected "
                f"Darija text only. Text: {text}")
            if out:
                return out.strip(), meaning
        except Exception:
            pass
    return original, meaning


def _extract_duration(command, default):
    m = re.search(r"(\d+)\s*(?:ثانية|second)", command or "")
    return int(m.group(1)) if m else default


def _extract_color(command):
    for word, color in COLOR_WORDS.items():
        if word in (command or ""):
            return color
    return None


def make_plan(command, template="Promo", brand="", main_text="",
              sub_text="", duration=17, gemini_key=None, topic_text=""):
    """Build a JSON plan. Gemini (REST) is tried first if a key is given,
    otherwise keyword parsing. Never crashes, never requires a key."""
    template_low = (template or "").lower()
    if "كويز" in (command or "") or "quiz" in (command or "").lower():
        template = "Quiz"
    elif "برومو" in (command or "") or "promo" in (command or "").lower():
        template = "Promo"
    elif "شرح" in (command or "") or "explainer" in (command or "").lower():
        template = "Explainer"
    duration = _extract_duration(command, duration)
    color = _extract_color(command) or "yellow"

    if gemini_key:
        try:
            from gemini_rest import generate_json
            plan = generate_json(
                gemini_key,
                "Convert this video command into JSON with duration, width "
                "1080, height 1920, fps 24, scenes with start, end, type, "
                f"text, color, bg, and voice_text. Command: {command}. "
                f"Template: {template}. Return JSON only.")
            if isinstance(plan, dict) and plan.get("scenes"):
                return plan
        except Exception:
            pass

    if template == "Promo":
        scenes = [
            {"start": 0, "end": 7, "type": "text_pop",
             "text": main_text or "MARKETING", "color": color, "bg": "orange"},
            {"start": 7, "end": 10, "type": "portfolio", "text": "Our Work"},
            {"start": 10, "end": 12, "type": "cta",
             "text": "WHAT are you waiting for?"},
            {"start": 12, "end": duration, "type": "logo_glow",
             "text": brand or "iD", "color": "green"},
        ]
        voice = "Why go anywhere else for your brand? We make your brand shine."
    elif template == "Quiz":
        scenes = [{"start": i * 10, "end": (i + 1) * 10, "type": "quiz",
                   "text": f"Question {i + 1}"} for i in range(6)]
        voice = "Question and answer, read in French."
    else:
        scenes = split_topic_to_scenes(topic_text or command or "Explainer",
                                       scene_seconds=10)
        voice = topic_text or command or ""
    return {"duration": duration, "width": 1080, "height": 1920, "fps": 24,
            "template": template, "scenes": scenes, "voice_text": voice}


def split_topic_to_scenes(topic_text, scene_seconds=10, gemini_key=None):
    """Split text at natural pauses; one idea per scene."""
    text = (topic_text or "").strip()
    if not text:
        return [{"start": 0, "end": scene_seconds, "type": "text_pop", "text": ""}]
    parts = [p.strip() for p in re.split(r"[.!؟\n]+", text) if p.strip()]
    scenes, t = [], 0
    for i, part in enumerate(parts):
        style = get_style_for_topic(part, gemini_key=gemini_key)
        keywords = []
        for ar, en in AR_TO_EN_KEYWORDS.items():
            if ar in part:
                keywords.append(en)
        scenes.append({"start": t, "end": t + scene_seconds, "type": "smart_frame",
                       "text": part, "category": style.get("category", "education"),
                       "style": style.get("label_ar", ""),
                       "image_keywords": keywords or ["cinematic"],
                       "animation": style.get("animation", "pop"),
                       "animation_speed": style.get("animation_speed", 1.0)})
        t += scene_seconds
    return scenes


def split_long_video(transcript, gemini_key=None):
    """Split a Whisper transcript (segments with start/end/text) into
    8-15s scenes, splitting on pauses >1.5s or topic change."""
    scenes, current, t = [], None, 0.0
    for seg in transcript or []:
        start = float(seg.get("start", t))
        text = seg.get("text", "").strip()
        if not text:
            continue
        if current is None:
            current = {"start": start, "end": start, "text": text}
        elif start - current["end"] > 1.5 or (start - current["start"] > 15):
            current["end"] = start
            scenes.append(_finish_scene(current, gemini_key))
            current = {"start": start, "end": start, "text": text}
        else:
            current["text"] += " " + text
        current["end"] = float(seg.get("end", start + 5))
    if current:
        scenes.append(_finish_scene(current, gemini_key))
    return scenes


def _finish_scene(scene, gemini_key=None):
    style = get_style_for_topic(scene["text"], gemini_key=gemini_key)
    scene = dict(scene)
    scene["category"] = style.get("category", "education")
    scene["style"] = style.get("label_ar", "")
    scene["animation"] = style.get("animation", "pop")
    # FIX #2: animation_speed only — playback stays 1.0x.
    scene["animation_speed"] = style.get("animation_speed", 1.0)
    scene["type"] = "smart_frame"
    return scene
