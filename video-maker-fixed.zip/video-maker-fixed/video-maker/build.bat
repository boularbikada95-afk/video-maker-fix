@echo off
pip install -r requirements.txt
pyinstaller --onefile --windowed --name VideoMaker app.py
echo EXE is in dist\VideoMaker.exe
echo NOTE: FFmpeg must still be installed separately on Windows.
pause
