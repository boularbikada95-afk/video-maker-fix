"""Smart B-Roll: search Pexels / Pixabay for a free image per scene.

Cache in assets/broll/<keyword>.jpg — never download the same keyword
twice. Any failure (no key, no internet, bad response) falls back to a
local image or a placeholder — never crashes.
"""
import os

import requests

from config import BROLL_DIR

AR_TO_EN = {
    "محرك طائرة": "jet engine", "محرك سيارة": "car engine",
    "طائرة": "airplane", "سيارة": "car", "بحر": "sea",
    "حب": "couple love", "فراق": "heartbreak",
}


def keyword_to_english(keyword):
    for ar, en in AR_TO_EN.items():
        if ar in keyword:
            return en
    return keyword


def _safe_name(keyword):
    return "".join(c if c.isalnum() else "_" for c in keyword)[:60] or "image"


def search_image(keyword, pexels_key=None, pixabay_key=None):
    """Return local path to an image, or None if nothing was found."""
    os.makedirs(BROLL_DIR, exist_ok=True)
    en = keyword_to_english(keyword)
    cached = os.path.join(BROLL_DIR, _safe_name(en) + ".jpg")
    if os.path.exists(cached):
        return cached
    url = None
    headers = {}
    if pexels_key:
        url = f"https://api.pexels.com/v1/search?query={en}&per_page=1&orientation=portrait"
        headers = {"Authorization": pexels_key}
    elif pixabay_key:
        url = ("https://pixabay.com/api/?key=" + pixabay_key +
               f"&q={en}&image_type=photo&orientation=vertical&per_page=3")
    if not url:
        return None
    try:
        resp = requests.get(url, headers=headers, timeout=20)
        if resp.status_code != 200:
            return None
        data = resp.json()
        if pexels_key:
            photos = data.get("photos") or []
            img_url = photos[0]["src"]["large"] if photos else None
        else:
            hits = data.get("hits") or []
            img_url = hits[0].get("largeImageURL") if hits else None
        if not img_url:
            return None
        img = requests.get(img_url, timeout=30)
        if img.status_code != 200:
            return None
        with open(cached, "wb") as f:
            f.write(img.content)
        return cached
    except Exception:
        return None
