"""FIX #7 — Replace the deprecated Gemini SDK with direct REST.

The old Gemini SDK is deprecated and pulls heavy deps.
This module calls the Gemini REST API directly with `requests` only:
  POST https://generativelanguage.googleapis.com/v1beta/models/
       gemini-2.0-flash:generateContent?key=API_KEY
Timeout 30s. Any error (network, bad key, bad JSON) returns None and
the caller MUST fall back to keyword parsing — never crash, never log
the API key.
"""
import json

import requests

from config import GEMINI_MODEL, GEMINI_TIMEOUT_S

BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"


def _parse_text(payload):
    try:
        candidates = payload.get("candidates") or []
        parts = candidates[0]["content"]["parts"]
        return "".join(p.get("text", "") for p in parts).strip()
    except Exception:
        return ""


def generate_text(api_key, prompt, timeout=GEMINI_TIMEOUT_S):
    """Return model text, or None on any failure. Key is never logged."""
    if not api_key:
        return None
    url = f"{BASE_URL}/{GEMINI_MODEL}:generateContent"
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        resp = requests.post(url, params={"key": api_key}, json=body,
                             timeout=timeout)
        if resp.status_code != 200:
            return None
        return _parse_text(resp.json()) or None
    except Exception:
        return None


def generate_json(api_key, prompt, timeout=GEMINI_TIMEOUT_S):
    """Return parsed JSON dict/list from the model, or None on failure."""
    text = generate_text(api_key, prompt, timeout=timeout)
    if not text:
        return None
    text = text.strip()
    # Strip markdown fences if the model wrapped the JSON.
    if text.startswith("```"):
        text = text.strip("`").strip()
        if text.lower().startswith("json"):
            text = text[4:].strip()
    try:
        return json.loads(text)
    except Exception:
        # Try to find the first {...} or [...] block.
        for start, end in (("{", "}"), ("[", "]")):
            try:
                i, j = text.index(start), text.rindex(end)
                return json.loads(text[i:j + 1])
            except Exception:
                continue
        return None
