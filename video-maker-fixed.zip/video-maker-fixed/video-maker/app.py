"""Video Maker — Streamlit UI (Arabic, RTL-friendly labels).

FIX #6: API keys can be remembered locally in .env (user's own PC only)
via the "تذكر المفاتيح" checkbox, using python-dotenv. Keys are never
logged and never committed (.env is in .gitignore). A "مسح المفاتيح
المحفوظة" button deletes them.
FIX #8: Whisper large-v3 warning in Arabic; default long-video model is
base; long video capped at 30 min by default, 60 min only with warning.
FIX #3: optional "اعزل المتحدث" checkbox (rembg, graceful fallback).
FIX #5: custom Darija words are saved to darija_custom.json, never to
darija_dict.py.
"""
import os

import streamlit as st

try:
    from dotenv import load_dotenv, set_key, unset_key
    load_dotenv()
except Exception:
    load_dotenv = lambda *a, **k: None
    set_key = lambda *a, **k: None
    unset_key = lambda *a, **k: None

from brain import (correct_darija_transcript, load_custom_darija,
                   make_plan, save_custom_darija, split_topic_to_scenes)
from config import (LONG_VIDEO_DEFAULT_MAX_MINUTES,
                    LONG_VIDEO_HARD_MAX_MINUTES, WHISPER_DEFAULT_LONG)
from renderer import render_long_video, render_video
from style_engine import get_style_for_topic
from voice import VOICES, make_voice

st.set_page_config(page_title="صانع الفيديو — Video Maker", layout="wide")
st.title("صانع الفيديو — Video Maker")

# --- FIX #8 warnings (Arabic, shown before any long render) ---
st.warning(
    "⚠️ تحذير الأداء: Whisper large-v3 على حاسوب بدون كرت NVIDIA قد "
    "يستغرق ساعات لفيديو 60 دقيقة. استعمل base للفيديوهات الطويلة، "
    "و large-v3 فقط لمقاطع دارجة قصيرة أو مع GPU.")

video_file = st.file_uploader("ارفع الفيديو الخام (mp4)", type=["mp4"])
command = st.text_input(
    "اكتب الأمر",
    "ديرلي برومو 17 ثانية، نص MARKETING أصفر، وفي الأخير اللوغو الأخضر")
topic_text = st.text_area(
    "اكتب أو الصق النص اللي تتكلم عليه",
    "كيف يعمل محرك الطائرة النفاثة؟ الهواء يدخل، ينضغط، يحترق، ويخرج بقوة")
template = st.selectbox("القالب", ["Promo", "Quiz", "Explainer", "Talk about a topic"])
mode = st.selectbox("النمط", ["فيديو قصير", "فيديو طويل (10-60 دقيقة)"])
brand = st.text_input("اسم البراند", "iD")
main_text = st.text_input("النص الرئيسي", "MARKETING")
logo_file = st.file_uploader("ارفع اللوغو (png, اختياري)", type=["png"])
bg_color = st.color_picker("لون الخلفية", "#EA580C")
accent_color = st.color_picker("لون التمييز", "#FACC15")
duration = st.slider("المدة (ثواني)", 15, 90, 17)
language = st.selectbox("اللغة", ["الدارجة الجزائرية", "الفصحى", "الفرنسية", "English"])
is_darija = st.checkbox("أنا أتكلم بالدارجة الجزائرية", value=True)
search_images = st.checkbox("ابحث عن صور تلقائيا", value=True)
adapt_style = st.checkbox("افهم كلامي وغير الستايل حسب الموضوع", value=True)
synced_captions = st.checkbox("كابشن متزامن مع الكلام", value=True)
isolate_speaker = st.checkbox("اعزل المتحدث (قص الخلفية - rembg)", value=False)
voice_label = st.selectbox("الصوت", list(VOICES.keys()))
whisper_model = st.selectbox(
    "نموذج Whisper", ["base", "small", "large-v3"],
    index=0 if mode.startswith("فيديو طويل") else 2,
    help="base سريع للفيديوهات الطويلة. large-v3 الأفضل للدارجة لكن بطيء جدا على CPU بدون GPU.")

# --- FIX #6: keys with remember checkbox ---
remember_keys = st.checkbox("تذكر المفاتيح على هذا الحاسوب", value=True)
gemini_key = st.text_input("مفتاح Gemini (مجاني، اختياري)",
                           value=os.getenv("GEMINI_API_KEY", ""), type="password")
pexels_key = st.text_input("مفتاح Pexels (مجاني، اختياري)",
                           value=os.getenv("PEXELS_API_KEY", ""), type="password")
pixabay_key = st.text_input("مفتاح Pixabay (مجاني، اختياري)",
                            value=os.getenv("PIXABAY_API_KEY", ""), type="password")
if st.button("مسح المفاتيح المحفوظة"):
    for k in ("GEMINI_API_KEY", "PEXELS_API_KEY", "PIXABAY_API_KEY"):
        try:
            unset_key(".env", k)
        except Exception:
            pass
        os.environ.pop(k, None)
    st.success("تم مسح المفاتيح المحفوظة.")

# --- FIX #5: custom Darija words -> JSON, never .py ---
st.subheader("كلمات خاصة بي (دارجة)")
custom_words = load_custom_darija()
new_word = st.text_input("كلمة بالدارجة")
new_meaning = st.text_input("معناها")
if st.button("أضف الكلمة"):
    if new_word and new_meaning:
        custom_words[new_word.strip()] = new_meaning.strip()
        save_custom_darija(custom_words)
        st.success(f"تمت إضافة: {new_word}")

if mode.startswith("فيديو طويل"):
    max_minutes = st.slider(
        "أقصى مدة للفيديو الطويل (دقائق)",
        10, LONG_VIDEO_HARD_MAX_MINUTES, LONG_VIDEO_DEFAULT_MAX_MINUTES)
    if max_minutes > LONG_VIDEO_DEFAULT_MAX_MINUTES:
        st.warning("⚠️ فيديو أطول من 30 دقيقة مع Whisper على CPU قد يستغرق "
                   "ساعات. استعمل base وتأكد من الوقت المتاح.")

if st.button("اصنع الفيديو — Render"):
    if remember_keys:
        try:
            if gemini_key:
                set_key(".env", "GEMINI_API_KEY", gemini_key)
            if pexels_key:
                set_key(".env", "PEXELS_API_KEY", pexels_key)
            if pixabay_key:
                set_key(".env", "PIXABAY_API_KEY", pixabay_key)
        except Exception:
            pass
    # Darija: show original + MSA meaning beside it.
    darija_orig, darija_msa = correct_darija_transcript(
        topic_text, gemini_key=gemini_key or None)
    st.write("النص الأصلي بالدارجة:", darija_orig)
    st.write("المعنى بالفصحى:", darija_msa)
    if adapt_style:
        style = get_style_for_topic(topic_text, gemini_key=gemini_key or None)
        st.write(f"الستايل المكتشف: {style.get('label_ar', '')} — "
                 f"{style.get('bg', '')} + {style.get('animation', '')}")
        st.color_picker("معاينة لون الستايل", style.get("bg", "#0F172A"))
    plan = make_plan(command, template=template, brand=brand,
                     main_text=main_text, duration=duration,
                     gemini_key=gemini_key or None, topic_text=topic_text)
    # Scene table.
    st.subheader("المشاهد")
    st.table([{"start": s.get("start"), "end": s.get("end"),
               "text": s.get("text", ""),
               "category": s.get("category", ""),
               "style": s.get("style", "")}
              for s in plan.get("scenes", [])])
    # Voice.
    voice_name = VOICES.get(voice_label, "en-US-GuyNeural")
    ok, used = make_voice(plan.get("voice_text", topic_text), voice_name,
                          output_path="voice.mp3", duration_seconds=duration)
    if not ok:
        st.warning("تعذر توليد الصوت، تم استعمال صوت صامت مؤقت.")
    progress = st.progress(0)
    if mode.startswith("فيديو طويل"):
        out = render_long_video(plan, output_path="output.mp4",
                                progress_callback=lambda p: progress.progress(p))
    else:
        out = render_video(plan, voice_path="voice.mp3", output_path="output.mp4",
                           progress_callback=lambda p: progress.progress(p),
                           isolate_speaker=isolate_speaker)
    st.video(out)
    st.success(f"تم! الملف: {out} — 1080x1920، 24fps، تشغيل 1.0x دائما")
    with open(out, "rb") as f:
        st.download_button("حمّل الفيديو", f, file_name="output.mp4")
