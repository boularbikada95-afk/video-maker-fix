"""FIX #1 — Arabic shaping on Windows.

Pillow does NOT shape Arabic on Windows by itself: letters appear
disconnected and reversed ("مقطّعة ومعكوسة"). Every Arabic string drawn
in this project MUST go through reshape_text() first, which uses
arabic-reshaper (join letters) + python-bidi (right-to-left order).
Use draw_arabic() for ALL captions and titles — never call
draw.text() directly with raw Arabic.

If the two libraries are missing, reshape_text() falls back to the
raw text (never crashes) and draw_arabic() still draws it.
"""
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    _HAS_ARABIC_LIBS = True
except Exception:  # pragma: no cover - missing optional deps
    arabic_reshaper = None
    get_display = None
    _HAS_ARABIC_LIBS = False


def has_arabic_support():
    return _HAS_ARABIC_LIBS


def is_arabic(text):
    if not text:
        return False
    return any("\u0600" <= ch <= "\u06ff" for ch in str(text))


def reshape_text(text):
    """Return display-ready text: reshaped + bidi-ordered if Arabic."""
    text = "" if text is None else str(text)
    if not text or not is_arabic(text) or not _HAS_ARABIC_LIBS:
        return text
    try:
        reshaped = arabic_reshaper.reshape(text)
        return get_display(reshaped)
    except Exception:
        return text


def draw_arabic(draw, xy, text, font=None, fill="white", anchor=None, **kwargs):
    """Draw text with Arabic shaping applied. Drop-in for draw.text()."""
    display = reshape_text(text)
    if anchor is not None:
        return draw.text(xy, display, font=font, fill=fill, anchor=anchor, **kwargs)
    return draw.text(xy, display, font=font, fill=fill, **kwargs)
