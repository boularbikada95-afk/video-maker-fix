"""Shared constants for Video Maker (merged v2).

FIX #2 — SPEED / SYNC (read this first):
  * PLAYBACK_SPEED is ALWAYS 1.0x. Audio and video playback never speed up
    or slow down. Whisper timestamps are the source of truth for captions.
  * ANIMATION_SPEED (0.9-1.3) only changes how fast an *animation* moves
    inside a scene (zoom, slide, pop). It never changes scene duration,
    audio speed, or caption timing. A "fast" sport style animates faster,
    it does NOT play the voice faster.
  * Old v1 profiles used speed 1.2x / 0.9x / 1.3x as playback speed — that
    broke audio/caption sync in long videos. That field is removed.
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
PORTFOLIO_DIR = os.path.join(ASSETS_DIR, "portfolio")
BROLL_DIR = os.path.join(ASSETS_DIR, "broll")
CHUNKS_DIR = os.path.join(BASE_DIR, "chunks")
STYLE_HISTORY_FILE = os.path.join(BASE_DIR, "style_history.json")
DARIJA_CUSTOM_FILE = os.path.join(BASE_DIR, "darija_custom.json")
ENV_FILE = os.path.join(BASE_DIR, ".env")

WIDTH, HEIGHT, FPS = 1080, 1920, 24
PLAYBACK_SPEED = 1.0  # NEVER change this. See module docstring.
AUDIO_NORM_LUFS = -16
CHUNK_SECONDS = 60
# FIX #8: default long-video cap is 30 min, not 60. 60 min is allowed only
# with an explicit warning (see app.py / README).
LONG_VIDEO_DEFAULT_MAX_MINUTES = 30
LONG_VIDEO_HARD_MAX_MINUTES = 60

# FIX #8: Whisper model guidance.
# base = fast, recommended for long videos on CPU.
# small = more accurate, slower. large-v3 = best for Darija, but on a CPU
# without an NVIDIA GPU it can take HOURS for a 60-min video. Use it only
# for short Darija clips, or with a GPU.
WHISPER_MODELS = ["base", "small", "large-v3"]
WHISPER_DEFAULT_LONG = "base"
WHISPER_DEFAULT_SHORT_DARIJA = "large-v3"

GEMINI_MODEL = "gemini-2.0-flash"
GEMINI_TIMEOUT_S = 30
