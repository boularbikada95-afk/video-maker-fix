# Video Maker — صانع الفيديو (Merged v2)

Free Python app: raw video + command (Arabic/Darija/English) = finished
vertical video 1080x1920, 24fps, no watermark.

## Install (Windows)
1. Install Python 3.11 and FFmpeg from gyan.dev, add FFmpeg to PATH.
2. `pip install -r requirements.txt`
3. `streamlit run app.py`  — or double-click `run.bat`.

## ⚠️ Performance warnings — تحذيرات الأداء (اقرأ قبل الفيديو الطويل)
- **Whisper large-v3 on a CPU without an NVIDIA GPU can take HOURS for a
  60-minute video.** Use `base` for long videos, `small` for accuracy,
  `large-v3` only for short Darija clips or with a GPU.
- Default long-video cap is **30 minutes**; 60 minutes is allowed only
  with an explicit warning in the UI.
- 1 minute of video ≈ 2–3 minutes of rendering on a normal PC.
- rembg downloads its u2net model (~170 MB) on first use; needs internet
  the first time. If it fails, the app falls back to a darkened
  background and never crashes.

## Fixes in v2 (all 8 Gemini flaws)
1. Arabic shaping: `arabic-reshaper` + `python-bidi`, `arabic_text.py`
   reshapes every caption/title before Pillow draws it.
2. Speed/sync: playback is ALWAYS 1.0x. `animation_speed` only changes
   how fast an animation moves; Whisper timestamps stay the source of
   truth for captions.
3. Background removal: `rembg` + `onnxruntime`, `bg_remove.py`, optional
   "اعزل المتحدث" checkbox, graceful fallback.
4. Modern motion graphics: PiP card with floating tags, 3x3 grid,
   particle ring for the logo, gradient mesh, staggered entrances.
   No flat "Work 1, Work 2, Work 3" cards.
5. Custom Darija words: saved to `darija_custom.json`, never by editing
   `darija_dict.py` (read-only base dict).
6. API keys: remembered locally in `.env` (own PC only, gitignored)
   with a "تذكر المفاتيح" checkbox and a clear-keys button.
7. Gemini via direct REST (`gemini_rest.py`, `requests` only).
   `google-generativeai` is removed.
8. Performance warnings above, in the UI and here; rembg + onnxruntime
   in requirements.txt.

## Free API keys (optional)
- Gemini: Google AI Studio (free tier, limited requests/day).
- Pexels: pexels.com/api — Pixabay: pixabay.com/api (free).

## Build EXE (Windows)
Double-click `build.bat`: `pyinstaller --onefile --windowed --name VideoMaker app.py`
FFmpeg must still be installed separately on Windows.

## Files
app.py, brain.py, renderer.py, voice.py, broll.py, style_engine.py,
long_video.py, darija_dict.py, darija_custom.json, arabic_text.py,
bg_remove.py, gemini_rest.py, config.py, templates/promo.py,
templates/quiz.py, templates/explainer.py
