"""Adaptive Style Engine.

FIX #2: profiles carry `animation_speed` (how fast the animation moves,
0.9-1.3), NEVER a playback speed. Playback is always 1.0x (config.py),
so audio and Whisper captions stay in sync.

Never repeat the same style twice in a row: style_history.json keeps
the last 5 styles; get_style_for_topic() varies the animation, accent
hue, or frame radius when the detected style equals the last one.
"""
import json
import os

from config import STYLE_HISTORY_FILE

# category -> keywords (Arabic/Darija/English/French)
CATEGORY_KEYWORDS = {
    "tech": ["محرك", "طائرة", "سيارة", "روبوت", "ذكاء", "engine", "robot", "car", "plane", "ai", "tech"],
    "nature": ["بحر", "غابة", "جبل", "طبيعة", "sea", "forest", "mountain", "nature", "animal"],
    "history": ["حرب", "تاريخ", "قديم", "حضارة", "war", "history", "ancient", "empire"],
    "business": ["براند", "تسويق", "شركة", "مال", "brand", "marketing", "business", "money", "shop"],
    "drama": ["رسالة", "سر", "خوف", "قصة", "drama", "secret", "mystery"],
    "education": ["تعلم", "كلمة", "تعريف", "درس", "learn", "word", "definition", "lesson", "quiz"],
    "food": ["طبخ", "أكل", "وصفة", "cooking", "food", "recipe"],
    "sport": ["كرة", "رياضة", "سباق", "football", "sport", "race"],
    "news": ["خبر", "عاجل", "نشرة", "إيران", "أمريكا", "news", "breaking"],
    "science": ["علم", "فضاء", "ذرة", "كوكب", "science", "space", "planet"],
    "relationships": ["حب", "علاقة", "زواج", "خطوبة", "خيانة", "فراق", "حبيب", "حبيبة", "قلب", "مشاعر", "حبيبي", "amour", "relation", "mariage", "coeur"],
}

# Each profile: bg, accent, font, animation, frame, transition, music, animation_speed.
# animation_speed != playback speed. Playback is always 1.0x.
PROFILES = {
    "tech": {"label_ar": "تقني", "bg": "#0F172A", "accent": "#00E5FF", "font": "bold", "animation": "fast zoom-in + slide from right", "frame": "sharp", "transition": "glitch cut", "music": "fast", "animation_speed": 1.2},
    "nature": {"label_ar": "طبيعة", "bg": "#14532D", "accent": "#A3E635", "font": "soft", "animation": "slow Ken Burns pan left to right", "frame": "rounded 60px", "transition": "crossfade", "music": "calm", "animation_speed": 0.9},
    "history": {"label_ar": "تاريخي", "bg": "#3B2F2F", "accent": "#D4AF37", "font": "serif", "animation": "slow fade + film grain", "frame": "vintage border", "transition": "dissolve", "music": "epic", "animation_speed": 0.9},
    "business": {"label_ar": "بيزنس", "bg": "#EA580C", "accent": "#FACC15", "font": "extra bold", "animation": "pop + bounce", "frame": "rounded 40px with shadow", "transition": "pop", "music": "energetic", "animation_speed": 1.1},
    "drama": {"label_ar": "دراما", "bg": "#000000", "accent": "#EF4444", "font": "cinematic", "animation": "slow zoom + vignette", "frame": "full screen", "transition": "fade to black", "music": "suspense", "animation_speed": 0.9},
    "education": {"label_ar": "تعليمي", "bg": "#F8F5E9", "accent": "#2563EB", "font": "clean", "animation": "pop + timer", "frame": "paper card", "transition": "slide up", "music": "light", "animation_speed": 1.0},
    "food": {"label_ar": "طبخ", "bg": "#7C2D12", "accent": "#FB923C", "font": "friendly", "animation": "slide from bottom + steam", "frame": "rounded 50px", "transition": "wipe", "music": "warm", "animation_speed": 1.0},
    "sport": {"label_ar": "رياضة", "bg": "#1E3A8A", "accent": "#22D3EE", "font": "italic bold", "animation": "fast slide + speed lines", "frame": "sharp", "transition": "fast cut", "music": "intense", "animation_speed": 1.3},
    "news": {"label_ar": "أخبار", "bg": "#7F1D1D", "accent": "#FFFFFF", "font": "news bold", "animation": "ticker + slide", "frame": "news bar on top", "transition": "cut", "music": "urgent", "animation_speed": 1.1},
    "science": {"label_ar": "علمي", "bg": "#020617", "accent": "#A855F7", "font": "futuristic", "animation": "float + stars", "frame": "glowing border", "transition": "star wipe", "music": "ambient", "animation_speed": 1.0},
    "romance": {"label_ar": "حب", "bg": "#831843", "accent": "#FB7185", "font": "elegant", "animation": "slow zoom + floating hearts", "frame": "rounded 60px with glow", "transition": "crossfade", "music": "romantic piano", "animation_speed": 0.9},
    "sad_drama": {"label_ar": "فراق", "bg": "#0F172A", "accent": "#93C5FD", "font": "cinematic", "animation": "slow zoom + rain", "frame": "full screen", "transition": "fade to black", "music": "sad piano", "animation_speed": 0.9},
    "advice": {"label_ar": "نصيحة", "bg": "#FEF3C7", "accent": "#0D9488", "font": "clean", "animation": "pop + check icons", "frame": "paper card", "transition": "slide up", "music": "light", "animation_speed": 1.0},
}

RELATIONSHIP_MOODS = {
    "romance": ["حب", "حبيبي", "عشق"],
    "sad_drama": ["فراق", "خيانة", "بعد", "وجع"],
    "advice": ["نصيحة", "كيفاش", "لازم", "علاش"],
}


def detect_topic_category(text, gemini_key=None):
    """Keyword classification first; Gemini (REST) only if a key is given."""
    text_low = (text or "").lower()
    if gemini_key:
        try:
            from gemini_rest import generate_text
            out = generate_text(
                gemini_key,
                "Classify this topic into exactly one word: tech, nature, "
                f"history, business, drama, education, food, sport, news, science, relationships. Topic: {text}")
            if out:
                cat = out.strip().lower().split()[0].strip(".,")
                if cat in CATEGORY_KEYWORDS:
                    return _relationships_mood(cat, text_low)
        except Exception:
            pass
    best, best_n = "education", 0
    for cat, kws in CATEGORY_KEYWORDS.items():
        n = sum(1 for k in kws if k.lower() in text_low)
        if n > best_n:
            best, best_n = cat, n
    return _relationships_mood(best, text_low)


def _relationships_mood(category, text_low):
    if category != "relationships":
        return category
    for mood, kws in RELATIONSHIP_MOODS.items():
        if any(k in text_low for k in kws):
            return mood
    return "romance"


def _load_history():
    try:
        with open(STYLE_HISTORY_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_history(history):
    try:
        with open(STYLE_HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history[-5:], f, ensure_ascii=False)
    except Exception:
        pass


def get_style_for_topic(text, previous_style=None, gemini_key=None):
    """Return a profile dict; never repeat the last style for a new topic."""
    category = detect_topic_category(text, gemini_key=gemini_key)
    profile = dict(PROFILES.get(category, PROFILES["education"]))
    profile["category"] = category
    history = _load_history()
    last = history[-1] if history else None
    if last == category:
        # Vary the animation direction / frame so it never looks identical.
        profile["animation"] = profile["animation"] + " (variant: reversed direction)"
        profile["variant"] = True
    history.append(category)
    _save_history(history)
    return profile


def list_categories():
    return list(CATEGORY_KEYWORDS.keys())
