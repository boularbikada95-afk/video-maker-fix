Cached B-roll images downloaded from Pexels/Pixabay are stored here, one file per keyword.
