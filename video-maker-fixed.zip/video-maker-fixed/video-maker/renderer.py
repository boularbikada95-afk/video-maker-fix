"""Renderer: Pillow frames -> FFmpeg, 1080x1920, 24fps.

FIX #2: playback is ALWAYS 1.0x. `animation_speed` only changes how
fast an animation moves inside a scene. Whisper timestamps are the
source of truth for captions — never stretched by a speed factor.
FIX #4: modern motion graphics — PiP card with floating tags, 3x3
rule-of-thirds grid, particle ring for the logo, gradient mesh
background, staggered entrances. No flat "Work 1, Work 2, Work 3" cards.
FIX #1: ALL Arabic text goes through arabic_text.draw_arabic().
FIX #3: optional speaker isolation via bg_remove.py (RGBA pasted over
rings/text behind him); on failure, darkened background fallback.
"""
import json
import math
import os
import subprocess

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from arabic_text import draw_arabic, reshape_text
from bg_remove import remove_background
from config import CHUNK_SECONDS, FPS, HEIGHT, PLAYBACK_SPEED, WIDTH

# PLAYBACK_SPEED must stay 1.0 — see config.py / FIX #2.
assert PLAYBACK_SPEED == 1.0


def _font(size, bold=True):
    for path in ("arial.ttf", "DejaVuSans-Bold.ttf", "DejaVuSans.ttf"):
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            continue
    return ImageFont.load_default()


def _ease_out(t):
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def draw_gradient_mesh(img, color1, color2):
    """Vertical gradient mesh background (two-colour blend)."""
    w, h = img.size
    top = Image.new("RGB", (1, h))
    top.putdata([tuple(int(a + (b - a) * y / max(1, h - 1))
                       for a, b in zip(color1, color2)) for y in range(h)])
    return top.resize((w, h))


def hex_to_rgb(hex_color):
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def draw_grid_3x3(draw, w=WIDTH, h=HEIGHT, color=(255, 255, 255, 40)):
    """FIX #4: subtle rule-of-thirds 3x3 grid overlay."""
    for x in (w // 3, 2 * w // 3):
        draw.line([(x, 0), (x, h)], fill=color, width=2)
    for y in (h // 3, 2 * h // 3):
        draw.line([(0, y), (w, y)], fill=color, width=2)


def draw_pip_card(base, image_path, box, progress, title="", caption=""):
    """FIX #4: PiP card — rounded corners, white border, soft shadow,
    Ken Burns zoom, title bar on top, caption at bottom."""
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    # Shadow.
    shadow = Image.new("RGBA", base.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.rounded_rectangle([x0 + 8, y0 + 12, x1 + 8, y1 + 12], radius=40,
                         fill=(0, 0, 0, 90))
    base.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(12)))
    if image_path and os.path.exists(image_path):
        try:
            img = Image.open(image_path).convert("RGB")
            zoom = 1.0 + 0.08 * _ease_out(progress)  # Ken Burns
            nw, nh = int(w * zoom), int(h * zoom)
            img = img.resize((nw, nh))
            left = (nw - w) // 2
            img = img.crop((left, 0, left + w, h))
        except Exception:
            img = Image.new("RGB", (w, h), (60, 60, 90))
    else:
        img = Image.new("RGB", (w, h), (60, 60, 90))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w, h], radius=40, fill=255)
    card = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    card.paste(img, (0, 0))
    card.putalpha(mask)
    base.alpha_composite(card, (x0, y0))
    d = ImageDraw.Draw(base)
    d.rounded_rectangle([x0, y0, x1, y1], radius=40,
                        outline=(255, 255, 255), width=8)
    if title:
        d.rectangle([x0, y0, x1, y0 + 90], fill=(0, 0, 0, 140))
        draw_arabic(d, (x0 + 30, y0 + 45), title, font=_font(54),
                    fill="white", anchor="lm")
    if caption:
        draw_arabic(d, ((x0 + x1) // 2, y1 - 50), caption, font=_font(44),
                    fill="white", anchor="mm")
    return base


def draw_floating_tags(draw, t, tags, w=WIDTH):
    """FIX #4: small floating tags that drift up slowly, staggered."""
    for i, tag in enumerate(tags or []):
        y = 300 + i * 90 - int(20 * math.sin(t * 1.5 + i))
        x = 80 + (i % 2) * 500
        draw.rounded_rectangle([x, y, x + 320, y + 64], radius=32,
                               fill=(255, 255, 255, 200))
        draw_arabic(draw, (x + 160, y + 32), tag, font=_font(38),
                    fill=(20, 20, 40), anchor="mm")


def draw_particle_ring(draw, cx, cy, radius, t, n=24, color=(0, 255, 170)):
    """FIX #4: particles orbiting the logo (drawn in code)."""
    for i in range(n):
        ang = 2 * math.pi * i / n + t * 0.8
        r = radius + 12 * math.sin(t * 2 + i)
        x = cx + int(r * math.cos(ang))
        y = cy + int(r * math.sin(ang))
        s = 6 + (i % 3) * 3
        draw.ellipse([x - s, y - s, x + s, y + s], fill=color)


def _draw_scene(img, scene, t, plan, raw_image=None, speaker_rgba=None):
    """Draw one frame. t is seconds into the scene (0..duration)."""
    bg_hex = scene.get("bg", "#0F172A") if isinstance(scene.get("bg"), str) else "#0F172A"
    try:
        c1 = hex_to_rgb(bg_hex)
    except Exception:
        c1 = (15, 23, 42)
    c2 = tuple(max(0, v - 40) for v in c1)
    frame = draw_gradient_mesh(Image.new("RGB", (WIDTH, HEIGHT)), c1, c2).convert("RGBA")
    d = ImageDraw.Draw(frame)
    draw_grid_3x3(d)
    anim_speed = float(scene.get("animation_speed", 1.0))  # animation only
    progress = _ease_out(min(1.0, t * anim_speed / max(1.0, scene.get("end", 10) - scene.get("start", 0))))
    text = scene.get("text", "")
    stype = scene.get("type", "text_pop")
    if speaker_rgba is not None:
        # FIX #3: speaker RGBA pasted over rings/text behind him.
        draw_particle_ring(d, WIDTH // 2, 900, 260, t)
        sp = speaker_rgba.copy()
        sp.thumbnail((700, 900))
        frame.alpha_composite(sp, ((WIDTH - sp.width) // 2, 700))
    if stype == "logo_glow":
        draw_particle_ring(d, WIDTH // 2, 900, 260, t)
        scale = 0.7 + 0.3 * progress
        draw_arabic(d, (WIDTH // 2, 900), text, font=_font(int(220 * scale)),
                    fill="white", anchor="mm")
    elif stype == "smart_frame":
        draw_pip_card(frame, raw_image, (60, 420, WIDTH - 60, 1500),
                      progress, title=scene.get("style", ""), caption=text[:60])
        draw_floating_tags(d, t, scene.get("image_keywords", [])[:2])
    elif stype == "portfolio":
        # FIX #4: PiP portfolio — no flat "Work 1/2/3" cards.
        draw_pip_card(frame, raw_image, (60, 500, WIDTH - 60, 1400),
                      progress, title="Our Work", caption="")
        draw_floating_tags(d, t, ["Video", "Design", "Promo"])
    else:
        scale = 0.6 + 0.4 * progress
        draw_arabic(d, (WIDTH // 2, 800), text, font=_font(int(130 * scale)),
                    fill=scene.get("color", "yellow"), anchor="mm")
    return frame.convert("RGB")


def render_video(plan, raw_video_path=None, logo_path=None, voice_path=None,
                 output_path="output.mp4", progress_callback=None,
                 isolate_speaker=False):
    """Render a short plan (<= ~2 min). Playback always 1.0x."""
    duration = float(plan.get("duration", 17))
    scenes = plan.get("scenes", [])
    speaker_rgba = None
    if isolate_speaker and raw_video_path:
        try:
            from PIL import Image as _Img
            speaker_rgba = remove_background(_Img.open(raw_video_path)) if os.path.isfile(raw_video_path) else None
        except Exception:
            speaker_rgba = None
    cmd = ["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", f"{WIDTH}x{HEIGHT}", "-r", str(FPS), "-i", "-"]
    has_valid_voice = bool(voice_path and os.path.exists(voice_path) and os.path.getsize(voice_path) > 100)
    if has_valid_voice:
        cmd += ["-i", voice_path, "-af", "apad", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-t", f"{duration:.3f}", output_path]
    else:
        cmd += ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-t", f"{duration:.3f}", output_path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    total = int(duration * FPS)
    try:
        for f in range(total):
            t = f / FPS
            scene = next((s for s in scenes if s.get("start", 0) <= t < s.get("end", 9999)), scenes[-1] if scenes else {})
            local_t = t - float(scene.get("start", 0))
            frame = _draw_scene(Image.new("RGB", (WIDTH, HEIGHT)),
                                scene, local_t, plan, speaker_rgba=speaker_rgba)
            try:
                proc.stdin.write(frame.tobytes())
            except BrokenPipeError:
                break
            if progress_callback and f % 24 == 0:
                progress_callback(f / max(1, total))
    finally:
        if proc.stdin:
            try:
                proc.stdin.close()
            except Exception:
                pass
        stderr_out = proc.stderr.read().decode("utf-8", errors="replace") if proc.stderr else ""
        rc = proc.wait()
        if rc != 0:
            raise RuntimeError(f"FFmpeg error ({rc}): {stderr_out[-500:]}")
    return output_path


def render_long_video(plan, raw_video_path=None, output_path="output.mp4",
                      progress_callback=None):
    """FIX: chunked rendering (60s chunks) + resume via checkpoint.json."""
    duration = float(plan.get("duration", 600))
    n_chunks = math.ceil(duration / CHUNK_SECONDS)
    os.makedirs("chunks", exist_ok=True)
    checkpoint = "checkpoint.json"
    done = 0
    try:
        with open(checkpoint, encoding="utf-8") as f:
            done = int(json.load(f).get("done_chunks", 0))
    except Exception:
        done = 0
    chunk_files = []
    for i in range(n_chunks):
        chunk_path = f"chunks/chunk_{i:03d}.mp4"
        chunk_files.append(chunk_path)
        if i < done and os.path.exists(chunk_path):
            continue
        sub = dict(plan)
        sub["duration"] = min(CHUNK_SECONDS, duration - i * CHUNK_SECONDS)
        sub["scenes"] = [dict(s, start=max(0, s.get("start", 0) - i * CHUNK_SECONDS),
                              end=s.get("end", 0) - i * CHUNK_SECONDS)
                         for s in plan.get("scenes", [])]
        render_video(sub, output_path=chunk_path)
        with open(checkpoint, "w", encoding="utf-8") as f:
            json.dump({"done_chunks": i + 1}, f)
        if progress_callback:
            progress_callback((i + 1) / n_chunks)
    with open("concat.txt", "w", encoding="utf-8") as f:
        for c in chunk_files:
            f.write(f"file '{c}'\n")
    subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0",
                    "-i", "concat.txt", "-c", "copy", output_path],
                   capture_output=True)
    return output_path
