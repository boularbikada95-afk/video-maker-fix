"""Voiceover with edge-tts (free, no API key).

If edge-tts fails, create a silent placeholder of the same duration so
FFmpeg does not crash, and return False so the UI can warn the user.
For Darija, try ar-DZ-AminaNeural first; if that voice is unavailable,
fall back to ar-SA-HamedNeural and report it (never claim a DZ voice
exists without testing it).
"""
import subprocess

VOICES = {
    "English Male": "en-US-GuyNeural",
    "English Female": "en-US-AriaNeural",
    "French": "fr-FR-HenriNeural",
    "Arabic Fusha": "ar-SA-HamedNeural",
    "Algerian Darija": "ar-DZ-AminaNeural",
}
DARIJA_FALLBACK = "ar-SA-HamedNeural"


def make_voice(text, voice_name="en-US-GuyNeural", output_path="voice.mp3",
               duration_seconds=10):
    """Return (ok, used_voice). ok=False means silent fallback was used."""
    if not text:
        text = " "
    for candidate in [voice_name, DARIJA_FALLBACK] if voice_name.startswith("ar-DZ") else [voice_name]:
        try:
            result = subprocess.run(
                ["edge-tts", "--voice", candidate, "--text", text,
                 "--write-media", output_path],
                capture_output=True, timeout=120)
            if result.returncode == 0:
                return True, candidate
        except Exception:
            continue
    # Silent fallback so FFmpeg never crashes on a missing voice file.
    try:
        subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i",
                        f"anullsrc=r=24000:cl=mono",
                        "-t", str(duration_seconds), "-c:a", "mp3",
                        output_path], capture_output=True, timeout=30)
    except Exception:
        pass
    return False, voice_name
