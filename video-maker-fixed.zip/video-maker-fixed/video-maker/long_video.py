"""Long video: Whisper transcription with timestamps.

FIX #8: default model for long videos is "base", NOT large-v3.
large-v3 on a CPU without an NVIDIA GPU can take HOURS for a 60-min
video. large-v3 is only the default for short Darija clips (or with GPU).
Audio is extracted first with FFmpeg; the whole video is never loaded
into RAM. Whisper is imported lazily so the app still starts without it.
"""
import json
import os
import subprocess

DARIJA_INITIAL_PROMPT = (
    "هذا كلام بالدارجة الجزائرية. كلمات شائعة: راني، واش، كيفاش، "
    "بزاف، دير، روح، جيب، شوف، علاش، وين، وقتاش، صحا، ياسر، درك، "
    "برك، كيما، هكذا، مليح، خايب، حبيبي، صاحبي.")


def extract_audio(video_path, wav_path="audio.wav"):
    subprocess.run(["ffmpeg", "-y", "-i", video_path, "-vn", "-ac", "1",
                    "-ar", "16000", wav_path],
                   capture_output=True, timeout=600)
    return wav_path


def transcribe_long_video(video_path, model_name="base", language=None,
                          output_json="transcript.json"):
    """Return list of {start, end, text} segments with word timestamps.

    Raises RuntimeError with an Arabic message if Whisper is missing.
    """
    try:
        import whisper
    except Exception as exc:
        raise RuntimeError("ثبت Whisper: pip install openai-whisper") from exc
    wav = extract_audio(video_path)
    model = whisper.load_model(model_name)
    kwargs = {"word_timestamps": True}
    if language:
        kwargs["language"] = language
    if language == "ar":
        kwargs["initial_prompt"] = DARIJA_INITIAL_PROMPT
    result = model.transcribe(wav, **kwargs)
    segments = [{"start": float(s.get("start", 0)),
                 "end": float(s.get("end", 0)),
                 "text": s.get("text", "").strip()}
                for s in result.get("segments", [])]
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(segments, f, ensure_ascii=False, indent=2)
    return segments
