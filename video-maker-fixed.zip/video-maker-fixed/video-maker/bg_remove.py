"""FIX #3 — Background removal (rembg, optional, graceful fallback).

remove_background(image) -> RGBA PIL image with the background removed,
or None if rembg / the model is unavailable (no internet, no model
download, missing package). Callers MUST check for None and fall back
to a darkened background — never crash.

Performance fix (2026-11-23): the rembg session is created ONCE and
cached in a module-level singleton, using the human-segmentation model
``u2net_human_seg`` — NOT the generic ``u2net`` model. Creating a new
session per frame would reload the model (~170 MB) on every frame and
fall back to the generic model, which is much slower and worse for
a talking presenter. The cached session is reused for every
consecutive video frame. Call clear_session() when rendering is done
to free memory.

Requires: rembg + onnxruntime (in requirements.txt). The rembg model
(u2net_human_seg) is downloaded on first use; that download is NOT done
at build/install time.
"""
import io

try:
    from rembg import remove as _rembg_remove
    from rembg import new_session as _new_session
    _HAS_REMBG = True
except Exception:
    _rembg_remove = None
    _new_session = None
    _HAS_REMBG = False

# Cached session — created lazily once, reused for all frames.
_SESSION = None
_SESSION_MODEL = "u2net_human_seg"


def has_bg_removal():
    return _HAS_REMBG


def _get_session():
    """Return the cached u2net_human_seg session, creating it once."""
    global _SESSION
    if _SESSION is not None:
        return _SESSION
    if not _HAS_REMBG or _new_session is None:
        return None
    # new_session downloads the model on first call (~170 MB) and
    # keeps the ONNX session in memory. Never call this per frame.
    _SESSION = _new_session(_SESSION_MODEL)
    return _SESSION


def clear_session():
    """Free the cached rembg session (call at end of a render)."""
    global _SESSION
    _SESSION = None


def remove_background(pil_image, session=None):
    """Return an RGBA image with background removed, or None on failure.

    Uses the cached u2net_human_seg session by default. An explicit
    session can be passed for testing; otherwise _get_session() is used.
    """
    if pil_image is None or not _HAS_REMBG:
        return None
    try:
        sess = session if session is not None else _get_session()
        if sess is None:
            return None
        buf = io.BytesIO()
        pil_image.save(buf, format="PNG")
        # Pass the cached session: this is the performance fix.
        # Without session=..., rembg creates a new generic u2net
        # session on every call.
        out = _rembg_remove(buf.getvalue(), session=sess)
        from PIL import Image
        result = Image.open(io.BytesIO(out)).convert("RGBA")
        return result
    except Exception:
        return None
